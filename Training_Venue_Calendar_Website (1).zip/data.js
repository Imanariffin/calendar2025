
const calendarData = {
  "January": [],
  "February": [],
  "March": [],
  "April": [],
  "May": [],
  "June": [],
  "July": [
    {"date": "1 July", "location": "Bay Alpha", "session": "Aim"},
    {"date": "2 July", "location": "Bay Alpha", "session": "Asmungi"},
    {"date": "3 July", "location": "Bay Alpha", "session": "Marie Ma"},
    {"date": "8 July", "location": "Bay Alpha", "session": "Azrel Amilin"},
    {"date": "10 July", "location": "Bay Alpha", "session": "DG Amilin Azrel"},
    {"date": "11 July", "location": "Bay Bravo", "session": "AVSEC Adina & Natasha"},
    {"date": "12 July", "location": "Bay Bravo", "session": "SLDN Amilin & Tuan Fendi"},
    {"date": "16 July", "location": "Northern Apron", "session": "AVSEC HQ"},
    {"date": "17 July", "location": "Runway 32", "session": "Marvel C11"},
    {"date": "18 July", "location": "Runway 32", "session": "Marvel C12"},
    {"date": "19 July", "location": "CBT Room", "session": "ASR Screener Course"},
    {"date": "21 July", "location": "TORA", "session": "UTW - Wan Noraini"},
    {"date": "22 July", "location": "TORA", "session": "UTW - Adli"},
    {"date": "23 July", "location": "ASDA", "session": "RFF - Tuan Anjas"},
    {"date": "24 July", "location": "ASDA", "session": "RFF - Fandy"}
  ],
  "August": [],
  "September": [],
  "October": [],
  "November": [],
  "December": []
};
