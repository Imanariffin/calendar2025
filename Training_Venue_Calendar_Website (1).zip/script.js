
const trainingData = calendarData;

function showMonth(month) {
  document.getElementById("month-title").textContent = month + " 2025";
  const tbody = document.getElementById("calendar-body");
  tbody.innerHTML = "";
  const data = trainingData[month] || [];

  if (data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;">No data available</td></tr>';
  } else {
    data.forEach(entry => {
      const row = `<tr><td>${entry.date}</td><td>${entry.location}</td><td>${entry.session}</td></tr>`;
      tbody.innerHTML += row;
    });
  }
}
